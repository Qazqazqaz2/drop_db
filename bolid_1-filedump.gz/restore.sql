--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bolid_1;
--
-- Name: bolid_1; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE bolid_1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


\connect bolid_1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id integer NOT NULL,
    name character varying NOT NULL,
    firmwares text[],
    settings text[],
    name_transcript character varying NOT NULL,
    specifics text,
    description text,
    dist_kit text[],
    docs text[],
    full_name character varying,
    path integer[]
);


--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes (
    name character varying,
    full_path integer[],
    id integer NOT NULL
);


--
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nodes_id_seq OWNED BY public.nodes.id;


--
-- Name: rubezh; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rubezh (
    id integer NOT NULL,
    name character varying,
    firmwares text[],
    big_desc text,
    name_transcript character varying,
    specifics text,
    description text,
    dist_kit text[],
    docs text[],
    full_name character varying,
    path integer[]
);


--
-- Name: rubezh_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rubezh_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rubezh_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rubezh_id_seq OWNED BY public.rubezh.id;


--
-- Name: statistic; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statistic (
    id integer NOT NULL,
    full_name character varying,
    count integer,
    options json,
    date date DEFAULT '2022-06-24'::date,
    "time" time without time zone DEFAULT '00:00:00'::time without time zone
);


--
-- Name: statistic_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statistic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statistic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statistic_id_seq OWNED BY public.statistic.id;


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: nodes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes ALTER COLUMN id SET DEFAULT nextval('public.nodes_id_seq'::regclass);


--
-- Name: rubezh id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rubezh ALTER COLUMN id SET DEFAULT nextval('public.rubezh_id_seq'::regclass);


--
-- Name: statistic id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statistic ALTER COLUMN id SET DEFAULT nextval('public.statistic_id_seq'::regclass);


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.items (id, name, firmwares, settings, name_transcript, specifics, description, dist_kit, docs, full_name, path) FROM stdin;
\.
COPY public.items (id, name, firmwares, settings, name_transcript, specifics, description, dist_kit, docs, full_name, path) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodes (name, full_path, id) FROM stdin;
\.
COPY public.nodes (name, full_path, id) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: rubezh; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rubezh (id, name, firmwares, big_desc, name_transcript, specifics, description, dist_kit, docs, full_name, path) FROM stdin;
\.
COPY public.rubezh (id, name, firmwares, big_desc, name_transcript, specifics, description, dist_kit, docs, full_name, path) FROM '$$PATH$$/3005.dat';

--
-- Data for Name: statistic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statistic (id, full_name, count, options, date, "time") FROM stdin;
\.
COPY public.statistic (id, full_name, count, options, date, "time") FROM '$$PATH$$/3003.dat';

--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.items_id_seq', 3164, true);


--
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nodes_id_seq', 8336, true);


--
-- Name: rubezh_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rubezh_id_seq', 197, true);


--
-- Name: statistic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statistic_id_seq', 479, true);


--
-- Name: items ins_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT ins_uniq UNIQUE (name, path);


--
-- Name: nodes ins_uniq_nod; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT ins_uniq_nod UNIQUE (name, full_path);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: rubezh rubezh_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rubezh
    ADD CONSTRAINT rubezh_pkey PRIMARY KEY (id);


--
-- Name: statistic statistic_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statistic
    ADD CONSTRAINT statistic_pkey PRIMARY KEY (id);


--
-- Name: DATABASE bolid_1; Type: ACL; Schema: -; Owner: -
--

GRANT CONNECT ON DATABASE bolid_1 TO user_readers;


--
-- Name: TABLE items; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.items TO user_reader;


--
-- Name: TABLE nodes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.nodes TO user_reader;


--
-- Name: TABLE rubezh; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.rubezh TO user_reader;


--
-- Name: TABLE statistic; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.statistic TO user_reader;


--
-- PostgreSQL database dump complete
--

